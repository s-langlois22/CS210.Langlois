#ifndef AIRGEAD_INVESTMENTCALCULATOR_H_
#define AIRGEAD_INVESTMENTCALCULATOR_H_

#include <vector>

class InvestmentCalculator {
public:
    InvestmentCalculator(double t_initialInvestment, double t_monthlyDeposit, double t_annualInterest, int t_years);
    void calculateGrowth();
    void displayReport() const;

private:
    double m_initialInvestment;
    double m_monthlyDeposit;
    double m_annualInterest;
    int m_years;

    struct YearlyReport {
        int year;
        double yearEndBalance;
        double yearEndInterest;
    };

    std::vector<YearlyReport> m_reportData;
};

#endif  // AIRGEAD_INVESTMENTCALCULATOR_H_
