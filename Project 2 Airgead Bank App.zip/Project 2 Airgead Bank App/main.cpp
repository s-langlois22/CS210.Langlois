#include <iostream>
#include <limits>
#include "InvestmentCalculator.h"

int main() {
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int years;

    std::cout << "========================================\n";
    std::cout << " Welcome to the Airgead Banking Program\n";
    std::cout << "========================================\n";

    std::cout << "Enter Initial Investment Amount: $";
    std::cin >> initialInvestment;

    std::cout << "Enter Monthly Deposit: $";
    std::cin >> monthlyDeposit;

    std::cout << "Enter Annual Interest Rate (percent): ";
    std::cin >> annualInterest;

    std::cout << "Enter Number of Years: ";
    std::cin >> years;

    if (initialInvestment < 0 || monthlyDeposit < 0 || annualInterest < 0 || years <= 0) {
        std::cerr << "Error: Please enter only positive values.\n";
        return 1;
    }

    InvestmentCalculator calculator(initialInvestment, monthlyDeposit, annualInterest, years);
    calculator.calculateGrowth();
    calculator.displayReport();

    return 0;
}
