#include <iostream>
#include <vector>
#include <iomanip>
#include "InvestmentCalculator.h"

InvestmentCalculator::InvestmentCalculator(double t_initialInvestment, double t_monthlyDeposit, double t_annualInterest, int t_years)
    : m_initialInvestment(t_initialInvestment), m_monthlyDeposit(t_monthlyDeposit),
      m_annualInterest(t_annualInterest), m_years(t_years) {}

void InvestmentCalculator::calculateGrowth() {
    m_reportData.clear();
    double balance = m_initialInvestment;
    double monthlyInterestRate = (m_annualInterest / 100.0) / 12.0;

    for (int year = 1; year <= m_years; ++year) {
        double interestEarned = 0.0;

        for (int month = 1; month <= 12; ++month) {
            double interest = (balance + m_monthlyDeposit) * monthlyInterestRate;
            interestEarned += interest;
            balance += m_monthlyDeposit + interest;
        }

        YearlyReport report{ year, balance, interestEarned };
        m_reportData.push_back(report);
    }
}

void InvestmentCalculator::displayReport() const {
    std::cout << "\n\n   Balance and Interest With Additional Monthly Deposits\n";
    std::cout << "===========================================================\n";
    std::cout << "  Year        Year End Balance        Year End Earned Interest\n";
    std::cout << "-----------------------------------------------------------\n";

    for (const auto& yearData : m_reportData) {
        std::cout << std::setw(6) << yearData.year
                  << std::setw(24) << std::fixed << std::setprecision(2) << yearData.yearEndBalance
                  << std::setw(30) << yearData.yearEndInterest << '\n';
    }
}
